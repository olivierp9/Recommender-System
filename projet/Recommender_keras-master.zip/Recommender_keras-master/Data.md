Data can be found here : <http://files.grouplens.org/datasets/movielens/ml-latest-small.zip>
