# Recommender_keras

Description of the approach : https://medium.com/@CVxTz/movie-recommender-model-in-keras-e1d015a0f513

Requirements : Keras, tensorflow, pandas, numpy 
